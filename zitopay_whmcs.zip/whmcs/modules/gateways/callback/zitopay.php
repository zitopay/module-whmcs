<?php
//////////////////////////////////////////////////////
//***************************************************/
//* Please see the ReadMe.txt file for instruction  */
//* This File is Written For ZitoPay Gateway       */
//* For Any Help, Contact me                        */
//***************************************************/
//* Email: support@zitopay.africa                    */
//* Phone: +237242015137                              */
//* Website: https://zitopay.africa                 */ 
//////////////////////////////////////////////////////


# Required File Includes
include("../../../init.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");

$gatewaymodule = "zitopay"; # Enter your gateway module name here replacing template

$GATEWAY = getGatewayVariables($gatewaymodule);
if (!$GATEWAY["type"]) die("Module Not Activated"); # Checks gateway module is active before accepting callback


$_REQUEST=array_merge($_GET,$_POST);
if(empty($_REQUEST['ref']))die("Transaction Reference not supplied");
$transaction_id = $_REQUEST['ref'];
$merchant_id = $GATEWAY['merchant_id'];

$data = file_get_contents("https://zitopay.africa/api_v1?ref=$transaction_id&action=get_transaction&receiver=$merchant_id");

$result = json_decode($data, true);
if(empty($result)) die("Invalid response from transaction validation");
if(!empty($result['error'])) die($result['error']);

$expl=explode('-',$transaction_id);
$invoice_id=$expl[0];
# Get Returned Variables - Adjust for Post Variable Names from your Gateway's Documentation
$status = $result['status'];
$transid = $transaction_id;

$invoiceid = checkCbInvoiceID($invoice_id,$GATEWAY["name"]); 
checkCbTransID($transid); 


if($result['status_msg']=='FAILED')logTransaction($GATEWAY["name"],$_POST,"Invoice Id: $invoice_id Failed. {$result['info']}");
elseif($result['status_msg']=='PENDING')logTransaction($GATEWAY["name"],$_POST,"Invoice Id: $invoice_id still on pending. {$result['info']}");
elseif($result['status_msg']=='COMPLETED'){
	if(false){
		$result = select_query("tblclients", "tblinvoices.invoicenum,tblclients.currency,tblcurrencies.code", array("tblinvoices.id" => $invoiceId), "", "", "", "tblinvoices ON tblinvoices.userid=tblclients.id INNER JOIN tblcurrencies ON tblcurrencies.id=tblclients.currency");
		$data = mysql_fetch_array($result);
		$currency_code = $data['currency'];
	}
	
	if(!empty($currency_code)&&$result['original_currency_code']!=$currency_code){
		logTransaction($GATEWAY["name"],$_POST,"Invoice Id $invoice_id:: Original payment currency tampered with. $currency_code expected but {$result['original_currency_code']} found on ZitoPay.");
	} /*
	elseif(floatval($result['original_amount'])<floatval($amount)){
		logTransaction($GATEWAY["name"],$_POST,"Incorrect deposit amount ($amount was expected, but {$result['original_amount']} found). ");
	}*/
	else {
		$fee = 0;
		$amount_paid=$result['original_amount'];
		addInvoicePayment($invoice_id,$transid,$amount_paid,$fee,$gatewaymodule); 
		logTransaction($GATEWAY["name"],$_POST,"Invoice Id: $invoice_id successfully completed. {$result['info']}");
	}
}

?>