<?php
//////////////////////////////////////////////////////
//***************************************************/
//* Do Not Run This File In Directly on ur Browser  */
//* Please see the ReadMe.txt file for instruction  */
//* This File is Written For Zitopay Gateway       */
//* For Any Help, Contact us                        */
//***************************************************/
//* Email: support@zitopay.africa                    */
//* Phone: +237242015137                              */
//* Website: https://zitopay.africa                 */ 
//////////////////////////////////////////////////////


function zitopay_config() {
    $configarray = array(
     "FriendlyName" => array("Type" => "System", "Value"=>"Zitopay Payment Gateway"),
     "merchant_id" => array("FriendlyName" => "Zitopay Username or Email", "Type" => "text", "Size" => "20", ),
    );
	return $configarray;
}

function zitopay_link($params) {
	
	# Gateway Specific Variables
	$merchant_id = $params['merchant_id'];
	/*
	$notify_url = $params['notification_url'];
	$fail_url = $params['fail_url'];
	$success_url = $params['success_url']; */
	

	# Invoice Variables
	$invoiceid = $params['invoiceid'];
	$description = $params['description'];
    $amount = $params['amount']; # Format: ##.##
    $currency = $params['currency']; # Currency Code

	# Client Variables
	$firstname = $params['clientdetails']['firstname'];
	$lastname = $params['clientdetails']['lastname'];
	$email = $params['clientdetails']['email'];
	$address1 = $params['clientdetails']['address1'];
	$address2 = $params['clientdetails']['address2'];
	$city = $params['clientdetails']['city'];
	$state = $params['clientdetails']['state'];
	$postcode = $params['clientdetails']['postcode'];
	$country = $params['clientdetails']['country'];
	$phone = $params['clientdetails']['phonenumber'];

	# System Variables
	$companyname = $params['companyname'];
	$systemurl = $params['systemurl'];
	$currency = $params['currency'];
	
	$trans_ref=$invoiceid.'-'.time();
 

	$isSSL = ((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||$_SERVER['SERVER_PORT']==443);
	$prot=$isSSL?'https://':'http://';
	$notification_url=$prot.$_SERVER['HTTP_HOST'].substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'],'/'))."/modules/gateways/callback/zitopay.php?trans_ref=$trans_ref";
	
	//i.e:: $notification_url="{$params['systemurl']}modules/gateways/callback/zitopay.php?trans_ref=$trans_ref";
	$success_url=$params['returnurl'];
	$cancel_url=$params['returnurl'];
	//$success_url=$notification_url;
	

	$code = "<form method='post' action='https://zitopay.africa/sci'>
	<input type='hidden' name='amount' value='$amount' />
	<input type='hidden' name='currency' value='$currency' />
	<input type='hidden' name='receiver' value='$merchant_id' />
	<input type='hidden' name='email' value='$email' />
	<input type='hidden' name='ref' value='$trans_ref' />
	<input type='hidden' name='memo' value=\"$description\" />
	<input type='hidden' name='notification_url' value='$notification_url' />
	<input type='hidden' name='success_url' value='$success_url' />
	<input type='hidden' name='cancel_url' value='$cancel_url' />
	<input type='submit' border='0' alt='We Accept Mobile Money' value='Pay With ZitoPay, Mobile Money & Bitcoin' />
	</form>";
	
	

	return $code;
}


?>